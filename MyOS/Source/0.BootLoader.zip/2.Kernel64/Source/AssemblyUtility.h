#ifndef AssemblyUtility_H
#define AssemblyUtility_H

#include "Types.h"

BYTE InPortByte(WORD wPort);
void OutPortByte(WORD wPort, BYTE bData);

void LoadGDTR(QWORD qwGDTRAddress);
void LoadTR(WORD wTSSSegmentOffset);
void LoadIDTR(QWORD qwIDTRAddress);

void EnableInterrupt();
void DisableInterrupt();
int Check();
QWORD ReadRFLAGS();

#endif