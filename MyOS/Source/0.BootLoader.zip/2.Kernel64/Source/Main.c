#include "Types.h"
#include "Keyboard.h"
#include "Descriptor.h"
#include "PIC.h"

void print(int x, int y, const char* string);

void Main()
{
	BYTE vcTemp[2] = { 0, };
	BYTE bFlags;
	BYTE bTemp;
	int i = 0;
	WORD what = 0;
	int up, down, middle;
	print(0, 10, "Switch To IA-32e Mode Success");
	print(0, 11, "IA-32e C Language Kernel start...................[Pass]");
	
	
	print(0, 12, "GDT Initialize And Switch For IA-32e Mode........[    ]");
	InitializeGDTTableAndTSS();
	LoadGDTR(GDTR_START_ADDRESS);
	print(50, 12, "Pass");
	
	print(0, 13, "TSS Segment Load.................................[    ]");
	LoadTR(GDT_TSSSEGMENT);
	print(50, 13, "Pass");

	print(0, 14, "IDT Initialize...................................[    ]");
	InitializeIDTTables();
	LoadIDTR(IDTR_START_ADDRESS);
	print(50, 14, "Pass");

	print(0, 15, "Keyboard Active..................................[    ]");
	if (ActivateKeyboard() == TRUE)
	{
		print(50, 15, "Pass");
		ChangeKeyboardLED(FALSE, FALSE, FALSE);
	}
	else
	{
		print(50, 15, "Fail");
		while (1);
	}
	
	print(0, 16, "PIC Controller And Interrupt Initialize..........[    ]");
	InitializePIC();
	MaskPICInterrupt(0);
	EnableInterrupt();
	print(50, 16, "Pass");
	
	while (1)
	{
		
		if (IsOutputBufferFull() == TRUE)
		{
			
			bTemp = GetKeyboardScanCode();
			if (ConvertScanCodeToASCIICode(bTemp, &(vcTemp[0]), &bFlags) == TRUE)
			{
				if (bFlags & KEY_FLAGS_DOWN)
				{
					print(i++, 17, vcTemp);
					if (vcTemp[0] == '0')
					{
						bTemp = bTemp / 0;
					}
				}
			}
		}
		
	}
}

void print(int x, int y, const char* string)
{
	VideoStruct* Screen = (VideoStruct*)0xB8000;
	int i;

	Screen += (y * 80) + x;

	for (i = 0; string[i] != 0; i++)
	{
		Screen[i].Charactor = string[i];
	}
}