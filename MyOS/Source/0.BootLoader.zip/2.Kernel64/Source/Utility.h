#ifndef Utility_H
#define Utility_H

#include "Types.h"

void MemorySet(void* pvDestination, BYTE bData, int iSize);
int MemoryCopy(void* pvDestination, const void* pvSource, int iSize);
int MemoryCompare(const void* pvDestination, const void* pvSource, int iSize);

#endif