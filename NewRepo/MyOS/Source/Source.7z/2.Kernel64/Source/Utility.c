#include "Utility.h"

void MemorySet(void* pvDestination, BYTE bData, int iSize)
{
	int i;

	for (i = 0; i < iSize; i++)
	{
		((char*)pvDestination)[i] = bData;
	}
}

int MemoryCopy(void* pvDestination, const void* pvSource, int iSize)
{
	int i;

	for (i = 0; i < iSize; i++)
	{
		((char*)pvDestination)[i] = ((char*)pvSource)[i];
	}
	return iSize;
}

int MemoryCompare(const void* pvDestination, const void* pvSource, int iSize)
{
	int i;
	char cTemp;

	for (i = 0; i < iSize; i++)
	{
		cTemp = ((char*)pvDestination)[i] - ((char*)pvSource)[i];
		if (cTemp != 0)
		{
			return (int)cTemp;
		}
	}
	return 0;
}